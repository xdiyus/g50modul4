package untitled.src.test.java;

public interface Runnable {
}
