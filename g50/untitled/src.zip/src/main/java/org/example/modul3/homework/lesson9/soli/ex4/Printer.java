package untitled.src.main.java.org.example.modul3.homework.lesson9.soli.ex4;

interface Printer {

void print(String text);


}
