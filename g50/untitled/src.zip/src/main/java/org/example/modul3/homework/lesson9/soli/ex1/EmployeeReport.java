package untitled.src.main.java.org.example.modul3.homework.lesson9.soli.ex1;

public class EmployeeReport {

    public void report(Employee employee) {
        System.out.println("Отчет: " + employee);
    }

}
