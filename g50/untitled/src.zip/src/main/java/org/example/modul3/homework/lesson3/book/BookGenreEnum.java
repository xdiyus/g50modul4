package untitled.src.main.java.org.example.modul3.homework.lesson3.book;

public enum BookGenreEnum {
    DETECTIVE,
    FANTASY,
    SCIENCE_FICTION,
    ROMANCE,
    MYSTERY,
    THRILLER;
}
