package untitled.src.main.java.org.example.modul3.repeat3modul.ex3.fruits;

import java.util.ArrayList;
import java.util.List;

public class FruitsImpl implements FruitsService{

List<String> fruit = new ArrayList<>();


    @Override
    public void ochirish(FruitsEnum fruitsEnum, int foiz) {

    }

    @Override
    public void tushurish(FruitsEnum fruitsEnum, int foiz) {

    }

    @Override
    public void remove(FruitsEnum fruitsEnum) {

    }

    @Override
    public void add(int index, FruitsEnum fruitsEnum) {

    }

    @Override
    public String toString() {
        return "FruitsImpl{" +
                "fruit=" + fruit +
                '}';
    }
}
