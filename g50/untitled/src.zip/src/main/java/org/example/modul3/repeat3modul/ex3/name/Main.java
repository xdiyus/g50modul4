package untitled.src.main.java.org.example.modul3.repeat3modul.ex3.name;

public class Main {
    public static void main(String[] args) {
        NameList name = new NameList();

        name.add("Diana");
        name.add("Diana");
        name.add("DIsna");
        name.add("Dffa");

        System.out.println(name);

        name.remove();
        System.out.println(name);

    }
}



