package untitled.src.main.java.org.example.modul3.repeat3modul.ex3.fruits;

public interface FruitsService {

    void ochirish(FruitsEnum fruitsEnum, int foiz);

    void tushurish(FruitsEnum fruitsEnum, int foiz);

    void remove(FruitsEnum fruitsEnum);

    void add(int index, FruitsEnum fruitsEnum);


}
