package untitled.src.main.java.org.example.modul3.homework.lesson1;

public class InvalidAgeException extends RuntimeException {
    public InvalidAgeException(String message) {
        super(message);
    }
}