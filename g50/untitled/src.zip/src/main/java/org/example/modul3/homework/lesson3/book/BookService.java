package untitled.src.main.java.org.example.modul3.homework.lesson3.book;

import java.util.List;

public interface BookService {
    void price();

    List<Book> newBooks();

    void removeBooks();

    void printBooks();
}
