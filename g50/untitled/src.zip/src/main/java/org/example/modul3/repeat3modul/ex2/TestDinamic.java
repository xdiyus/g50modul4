package untitled.src.main.java.org.example.modul3.repeat3modul.ex2;

public class TestDinamic {
    public static void main(String[] args) {
//        Generic<String> generic= new Generic<>();
//        generic.add("Diana");
//        generic.add("Koho");
//        System.out.println(generic);
//        generic.remove(2);
//        System.out.println(generic);
    }
}
