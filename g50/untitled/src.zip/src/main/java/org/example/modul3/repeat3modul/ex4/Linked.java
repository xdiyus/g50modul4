package untitled.src.main.java.org.example.modul3.repeat3modul.ex4;

public class Linked{

    public static void main(String[] args) {

     TestLink<String> name = new TestLink<>();
     name.add("Diana");
     name.add("Dian");
     name.add("Dia");
        System.out.println(name);

    }
}
