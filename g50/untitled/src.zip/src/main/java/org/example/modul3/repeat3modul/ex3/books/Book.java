package untitled.src.main.java.org.example.modul3.repeat3modul.ex3.books;

public class Book {







}
