package untitled.src.main.java.org.example.modul3.homework.lesson9.soli.ex2;
// Open/Closed Principle (Принцип открытости/закрытости)

abstract class Shape {
    abstract double calculateArea();
}
