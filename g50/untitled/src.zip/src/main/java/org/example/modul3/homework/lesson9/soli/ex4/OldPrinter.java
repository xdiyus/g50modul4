package untitled.src.main.java.org.example.modul3.homework.lesson9.soli.ex4;

public class OldPrinter implements Printer {
    @Override
    public void print(String text) {
        System.out.println("Printing " + text);
    }
}
