package untitled.src.main.java.org.example.modul3.homework.lesson1;

public class StudentNotFoundExceptionga extends RuntimeException {
    public StudentNotFoundExceptionga(String message) {
        super(message);
    }
}
