package untitled.src.main.java.org.example.modul3.homework.lesson9.soli.ex1;

public class Test {
    public static void main(String[] args) {
        Employee employee = new Employee("Alice", "Developer");
        EmployeeReport report = new EmployeeReport();
        report.report(employee);
    }
}
