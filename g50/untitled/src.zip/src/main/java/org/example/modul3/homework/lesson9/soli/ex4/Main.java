package untitled.src.main.java.org.example.modul3.homework.lesson9.soli.ex4;

public class Main {


    public static void main(String[] args) {
        Printer printer = new ServicePrint();
        printer.print("Heloooooo");


        Scanner scanner = new ServicePrint();
        scanner.scan("PDf");
    }
}
