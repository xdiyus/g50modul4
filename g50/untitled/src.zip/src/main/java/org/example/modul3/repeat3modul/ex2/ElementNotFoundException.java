package untitled.src.main.java.org.example.modul3.repeat3modul.ex2;

public class ElementNotFoundException extends RuntimeException {
    public ElementNotFoundException(String message) {
        super(message);
    }
}
