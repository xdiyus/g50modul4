package untitled.src.main.java.org.example.modul3.homework.lesson3.fruits;

public enum FruitType {
    SITRUS,
    XOLMEVA;
}
