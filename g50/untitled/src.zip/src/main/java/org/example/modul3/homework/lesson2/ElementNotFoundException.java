package untitled.src.main.java.org.example.modul3.homework.lesson2;

public class ElementNotFoundException extends RuntimeException {
    public ElementNotFoundException(String message) {
        super(message);
    }
}
