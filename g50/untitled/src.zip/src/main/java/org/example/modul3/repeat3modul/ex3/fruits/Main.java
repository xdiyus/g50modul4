package untitled.src.main.java.org.example.modul3.repeat3modul.ex3.fruits;

public class Main {
}
