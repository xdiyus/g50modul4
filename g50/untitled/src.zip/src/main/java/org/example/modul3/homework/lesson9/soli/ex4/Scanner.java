package untitled.src.main.java.org.example.modul3.homework.lesson9.soli.ex4;
//Принцип разделения интерфейса)
public interface Scanner {

    void scan (String document);
}
