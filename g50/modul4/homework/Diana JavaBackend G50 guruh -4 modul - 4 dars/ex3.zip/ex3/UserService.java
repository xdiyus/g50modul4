package modul4.homework.less4.ex3;

import untitled.src.main.java.org.example.modul3.homework.lesson5.ex1.User;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class UserService {
    public void register() {
        long startTime = System.currentTimeMillis();
        save();
        generateCode();
        send();
        long endTime = System.currentTimeMillis();
        System.out.println("Single thread vaqt: " + (endTime - startTime) + " ms");
    }

    public void registerWithFutures() throws InterruptedException, ExecutionException {
        ExecutorService executor = Executors.newFixedThreadPool(3);

        long startTime = System.currentTimeMillis();
        Future<Void> userFuture = executor.submit(() -> {
            save();
            return null;
        });
        Future<String> codeFuture = executor.submit(this::generateCode);
        Future<Boolean> inviteFuture = executor.submit(this::send);

        userFuture.get();
        codeFuture.get();
        inviteFuture.get();
        long endTime = System.currentTimeMillis();

        System.out.println("Futures bilan vaqt: " + (endTime - startTime) + " ms");
        executor.shutdown();
    }

    private void save() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println("User saqlandi.");
    }

    private String generateCode() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println("Kod generatsiya qilindi.");
        return "12345";
    }

    private boolean send() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println("Taklif yuborildi!!");
        return true;
    }
}
class Test{
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        UserService userService = new UserService();
        userService.register();
        userService.registerWithFutures();
    }
}

