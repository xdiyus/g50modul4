package modul4.homework.less4.ex1;

import org.w3c.dom.ls.LSOutput;

import java.sql.SQLOutput;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ExecutionComparison {
    public static void main(String[] args) {
        int count = 100;

        ExecutorService executionComparison = Executors.newFixedThreadPool(10);
        long start = System.currentTimeMillis();
        for (int i = 0; i < count; i++) {
            executionComparison.submit(() -> {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });

        }
        executionComparison.shutdown();
        try {
            executionComparison.awaitTermination(1, TimeUnit.MINUTES);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        long end = System.currentTimeMillis();
        System.out.println("10 ta bilan: " + (end - start) + " ms ");


        ExecutorService singleex = Executors.newSingleThreadExecutor();
        start = System.currentTimeMillis();
        for (int co = 0; co < count; co++) {

            singleex.submit(() -> {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            });
        }
        singleex.shutdown();
        try {
            singleex.awaitTermination(1, TimeUnit.MINUTES);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        end = System.currentTimeMillis();
        System.out.println("Bitaa bilan: " + (end - start) + " ms");//srazu chiqmidi bunisi
    }
}



