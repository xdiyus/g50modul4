package modul4.homework.less4.ex2;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static java.lang.System.currentTimeMillis;

public class Chached {


    public static void main(String[] args) throws InterruptedException {
        int count = 100;
        ExecutorService fixed = Executors.newFixedThreadPool(10);
        long start = currentTimeMillis();
        for (int i = 0; i < count; i++) {
            fixed.submit(() -> {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });
        }
        fixed.shutdown();
        fixed.awaitTermination(1, TimeUnit.MINUTES);
        long fixedTime = currentTimeMillis() - start;


        ExecutorService executorService = Executors.newCachedThreadPool();
        start = currentTimeMillis();
        for (int i = 0; i < count; i++) {
            executorService.submit(() -> {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });
        }
        executorService.shutdown();
        executorService.awaitTermination(1, TimeUnit.MINUTES);
        long time = System.currentTimeMillis() - start;

        System.out.println("10 ta bilan: " + fixedTime);
        System.out.println("Cached pool: " + time);

    }
}
